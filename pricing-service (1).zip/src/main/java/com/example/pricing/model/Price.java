
package com.example.pricing.model;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Price {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String storeId;
    private String articleId;
    private String type;
    private String subtype;
    private String currency;
    private Double amount;

    private LocalDateTime validFrom;
    private LocalDateTime validTo;

    private boolean overlapped;

    // Getters and Setters
}
