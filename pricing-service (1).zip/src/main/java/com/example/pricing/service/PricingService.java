
package com.example.pricing.service;

import com.example.pricing.model.Price;
import com.example.pricing.repository.PriceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class PricingService {

    @Autowired
    private PriceRepository priceRepository;

    public ResponseEntity<?> getPrices(String storeId, String articleId, int page, int pageSize) {
        List<Price> prices = priceRepository.findByStoreIdAndArticleId(storeId, articleId);

        if (prices.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of(
                            "type", "Not_Found",
                            "title", "Unavailable prices",
                            "status", 404,
                            "detail", "No prices were found for the given request"
                    ));
        }

        List<Price> paginatedPrices = paginate(prices, page, pageSize);

        return ResponseEntity.ok(Map.of(
                "generated_date", LocalDateTime.now(),
                "article", articleId,
                "store", storeId,
                "meta", Map.of("page", page, "size", pageSize),
                "prices", paginatedPrices
        ));
    }

    private List<Price> paginate(List<Price> prices, int page, int pageSize) {
        int start = Math.min((page - 1) * pageSize, prices.size());
        int end = Math.min(start + pageSize, prices.size());
        return prices.subList(start, end);
    }
}
