
package com.example.pricing.controller;

import com.example.pricing.service.PricingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/pricing/v1")
public class PricingController {

    @Autowired
    private PricingService pricingService;

    @GetMapping("/prices/{storeId}/{articleId}")
    public ResponseEntity<?> getPrices(@PathVariable String storeId, 
                                       @PathVariable String articleId,
                                       @RequestParam int page,
                                       @RequestParam int pageSize) {
        return pricingService.getPrices(storeId, articleId, page, pageSize);
    }
}
